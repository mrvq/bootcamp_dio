package dio.desafio.api.cep.cepapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CepapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CepapiApplication.class, args);
	}

}
