package com.example.cepapi.observer;

import com.example.cepapi.model.CepResponse;

public interface CepObserver {
    void notificar(String cep, CepResponse response);
}