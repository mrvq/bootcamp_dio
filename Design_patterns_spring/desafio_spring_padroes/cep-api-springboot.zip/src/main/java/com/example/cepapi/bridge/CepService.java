package com.example.cepapi.bridge;

import com.example.cepapi.model.CepResponse;

public interface CepService {
    CepResponse buscarCep(String cep);
}