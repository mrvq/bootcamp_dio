package com.example.cepapi.observer;

import com.example.cepapi.model.CepResponse;
import org.springframework.stereotype.Component;

@Component
public class LoggingObserver implements CepObserver {

    @Override
    public void notificar(String cep, CepResponse response) {
        System.out.println("Consulta realizada para o CEP: " + cep + " -> " + response);
    }
}