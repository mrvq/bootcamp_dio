package com.example.cepapi.factory;

import com.example.cepapi.bridge.CepService;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class CepServiceFactory {

    private final ApplicationContext context;

    public CepServiceFactory(ApplicationContext context) {
        this.context = context;
    }

    public CepService getService(String tipo) {
        return (CepService) context.getBean(tipo);
    }
}